const WORDS: Record<number, string[]> = {
  1: ['ash', 'calm', 'drift', 'echo', 'faint', 'glow', 'hush', 'mist', 'pulse', 'still', 'trace', 'wave'],
  2: ['anchor', 'breeze', 'canvas', 'distant', 'ember', 'frozen', 'gentle', 'hollow', 'motion', 'silver', 'velvet', 'window'],
  3: ['afterglow', 'blueprint', 'daydream', 'evergreen', 'fragments', 'midnight', 'overcast', 'quietly', 'remember', 'threshold'],
  4: ['architecture', 'constellation', 'disconnected', 'independent', 'observation', 'perception', 'recollection', 'transmission'],
}

export function getWord(level: number, previousWord = ''): string {
  const pool = WORDS[level] ?? WORDS[4]
  let word = pool[Math.floor(Math.random() * pool.length)]

  // Avoid showing the same word twice in a row when the pool allows it.
  if (pool.length > 1) {
    while (word === previousWord) {
      word = pool[Math.floor(Math.random() * pool.length)]
    }
  }

  return word
}

export function getDifficulty(completedWords: number): number {
  if (completedWords >= 60) return 4
  if (completedWords >= 30) return 3
  if (completedWords >= 12) return 2
  return 1
}
